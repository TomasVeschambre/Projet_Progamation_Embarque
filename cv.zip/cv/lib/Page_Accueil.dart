import 'package:flutter/material.dart';
import 'main.dart';
import 'Page 2.dart';


class Page_Accueil extends StatefulWidget {
  @override
  _Page_AccueilState createState() => _Page_AccueilState();
}

class _Page_AccueilState extends State<Page_Accueil> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              GestureDetector(
                  onTap: (){
               Navigator.push(
                context,
                     MaterialPageRoute(
                          builder: (context) => Page2(),
        ),
      );
    },
                  child : CircleAvatar(
                radius: 70.0,
                backgroundImage: AssetImage('images/zoro.jpeg'),
              ),
                ),
              Container(
                margin: EdgeInsets.all(30.0),
                padding: EdgeInsets.all(15.0),
                decoration: BoxDecoration(
                    color: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.circular(10.0)
                ),
                height: 60.0,
                width: 300.0,
                child: Center(
                  child: Text(
                      "Tomas Veschambre",
                      style : TextStyle(
                        fontSize: 20.0,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(30.0),
                padding: EdgeInsets.all(15.0),
                decoration: BoxDecoration(
                    color: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.circular(10.0)
                ),
                height: 60.0,
                width: 300.0,
                child : Center(
                    child : Text(
                        "Ingenieur",
                        style : TextStyle(
                          fontSize : 20.0,
                          color:Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                    ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(15.0),
                decoration: BoxDecoration(
                    color: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.circular(10.0)
                ),
                child : ListTile(
                    leading : Icon(
                      Icons.call,
                      size: 20.0,
                      color: Colors.white,
                    ),
                    title : Text(
                      '06 77 47 74 09',
                      style: TextStyle(
                        fontSize:20.0,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(15.0),
                decoration: BoxDecoration(
                    color: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.circular(10.0)
                ),
                child: ListTile(
                    leading : Icon(
                      Icons.email,
                      size:20.0,
                      color: Colors.white,
                    ),
                    title : Text(
                      'tomas.vesch@gmail.com',
                      style: TextStyle(
                        fontSize: 20.0,
                        color : Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                ),
              ),
            ],
          ),
        ),
      ),

    );
  }
}
