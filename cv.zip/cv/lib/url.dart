import 'package:flutter/material.dart';
import 'dart:core';
import 'package:url_launcher/url_launcher.dart';
/*
final Uri _formation1LaunchUri;

void main() {
  runApp(Scaffold(
    body: Center(
      child: RaisedButton(
        onPressed: _launchURL,
        child: Text('Show Flutter homepage'),
      ),
    ),
  ));
}

_launchURL() async {
  const url = 'http://coubertin-meaux.fr/';
 // const url1 = 'https://www.lyceemlk.net/';
 // const url3 = 'https://episen.u-pec.fr//';
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}

final Uri _formation1LaunchUri = Uri(
  scheme: 'http',
  path: 'http://coubertin-meaux.fr/',
);

launch(_formation1LaunchUri.toString());
*/