import 'package:cv/Langues.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'Academique.dart';
import 'Langues.dart';
import 'Autres.dart';
import 'Professionel.dart';

import 'Page_Accueil.dart';

class Page2 extends StatefulWidget {
  @override
  _Page2State createState() => _Page2State();
}

class _Page2State extends State<Page2> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded (
                 child : GestureDetector(
                    onTap: (){
                  Navigator.push(
                       context,
                           MaterialPageRoute(
                                 builder: (context) => Page_Accueil(),
        ),
        );
        },
              child : Container(
                  margin: EdgeInsets.all(15.0),
                  decoration: BoxDecoration(
                    color: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.circular(10.0)
                  ),
                height : 200.0,
                width: 300.0,
                child : Row(
                  children : [
                  CircleAvatar(
                    radius: 30.0,
                    backgroundImage: AssetImage('images/zoro.jpeg'),
                  ),
                    Text('Tomas VESCHAMBRE')
                  ],
                ),
              ),
        ),
              ),
              Expanded (
                child : Container(
                  child: Center(
                    child: Text(
                      "Curriculum Vitae",
                      style : TextStyle(
                        fontSize: 40.0,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
              Row(
                  children: <Widget>[
              Expanded (
                child : GestureDetector(
                  onTap: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Academique(),
                      ),
                    );
                  },
                child : Container (
                  margin: EdgeInsets.all(15.0),
                  decoration: BoxDecoration(
                      color: Colors.deepOrangeAccent,
                      borderRadius: BorderRadius.circular(10.0)
                  ),
                  height : 200.0,
                  width: 170.0,
                  child: Center(
                    child: Text(
                      "Académique",
                      style : TextStyle(
                        fontSize: 30.0,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
              ),
                    Expanded (

                      child : GestureDetector(
                        onTap: (){
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => Professionel(),
                            ),
                          );
                        },
                      child : Container (
                        margin: EdgeInsets.all(15.0),
                        decoration: BoxDecoration(
                            color: Colors.deepOrangeAccent,
                            borderRadius: BorderRadius.circular(10.0)
                        ),
                        height : 200.0,
                        width: 170.0,
                        child: Center(
                          child: Text(
                            "Professionel",
                            style : TextStyle(
                              fontSize: 30.0,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                    ),
            ],
          ),
    Row(
    children: <Widget>[
    Expanded (
      child : GestureDetector(
        onTap: (){
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Langues(),
            ),
          );
        },
            child : Container (
              margin: EdgeInsets.all(15.0),
              decoration: BoxDecoration(
                  color: Colors.deepOrangeAccent,
                  borderRadius: BorderRadius.circular(10.0)
              ),

              height : 200.0,
              width: 170.0,

              child: Center(
                child: Text(
                  "Langues",
                   style : TextStyle(

                     fontSize: 30.0,
                 color: Colors.white,
                 fontWeight: FontWeight.bold,
    ),
    ),
    ),
            ),
      ),
    ),
    Expanded (

      child : GestureDetector(
        onTap: (){
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Autres(),
            ),
          );
        },
            child : Container (
              margin: EdgeInsets.all(15.0),
              decoration: BoxDecoration(
                  color: Colors.deepOrangeAccent,
                  borderRadius: BorderRadius.circular(10.0)
              ),
              height : 200.0,
              width: 170.0,
              child: Center(
                child: Text(
                "Autres",
                   style : TextStyle(
                     fontSize: 30.0,
                         color: Colors.white,
                         fontWeight: FontWeight.bold,
    ),
    ),
    ),
    ),
    ),
    ),
    ],
    ),
      ],
        ),
      ),
      ),
    );
  }
}
