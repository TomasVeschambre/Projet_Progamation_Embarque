import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'Page 2.dart';
import 'Page_Accueil.dart';

class Langues extends StatefulWidget {
  @override
  _LanguesState createState() => _LanguesState();
}

class _LanguesState extends State<Langues> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
          Expanded (
          child : GestureDetector(
              onTap: (){
        Navigator.push(
        context,
        MaterialPageRoute(
        builder: (context) => Page_Accueil(),
        ),
        );
        },
          child : Container(
            margin: EdgeInsets.all(15.0),
            decoration: BoxDecoration(
                color: Colors.deepOrangeAccent,
                borderRadius: BorderRadius.circular(10.0)
            ),
            height : 200.0,
            width: 300.0,
            child : Row(
              children : [
                CircleAvatar(
                  radius: 30.0,
                  backgroundImage: AssetImage('images/zoro.jpeg'),
                ),
                Text('Tomas VESCHAMBRE')
              ],
            ),
          ),
        ),
      ),
                Expanded (
                  child : Container(
                    child: Center(
                      child: Text(
                        "Langues",
                        style : TextStyle(
                          fontSize: 40.0,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                child : Container(
                  margin: EdgeInsets.all(15.0),
                  padding: EdgeInsets.all(15.0),
                  decoration: BoxDecoration(
                      color: Colors.deepOrangeAccent,
                      borderRadius: BorderRadius.circular(10.0)
                  ),
                  height : 150.0,
                  width: 300.0,
                  child : ListTile(
                      leading : Icon(
                        FontAwesomeIcons.flagUsa,
                        size: 20.0,
                        color: Colors.white,
                      ),
                        title :  Text(
                        'Anglais',
                        style: TextStyle(
                          fontSize:20.0,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                        ),
                      ),
                  ),
                ),
                Expanded(
                  child : Container(
                    margin: EdgeInsets.all(15.0),
                    padding: EdgeInsets.all(15.0),
                    decoration: BoxDecoration(
                        color: Colors.deepOrangeAccent,
                        borderRadius: BorderRadius.circular(10.0)
                    ),
                    height : 150.0,
                    width: 300.0,
                    child : ListTile(
                        leading : Icon(
                          FontAwesomeIcons.flag,
                          size: 20.0,
                          color: Colors.white,
                        ),
                        title : Text(
                          'Allemand',
                          style: TextStyle(
                            fontSize:20.0,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                    ),
                  ),
                ),
                Expanded(
                  child : Container(
                    margin: EdgeInsets.all(15.0),
                    padding: EdgeInsets.all(15.0),
                    decoration: BoxDecoration(
                        color: Colors.deepOrangeAccent,
                        borderRadius: BorderRadius.circular(10.0)
                    ),
                    height : 150.0,
                    width: 300.0,
                    child : ListTile(
                        leading : Icon(
                          FontAwesomeIcons.fontAwesomeFlag,
                          size: 20.0,
                          color: Colors.white,
                        ),
                        title : Text(
                          'Japonais',
                          style: TextStyle(
                            fontSize:20.0,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                    ),
                  ),
                ),
                FloatingActionButton(
                  child : GestureDetector(
                  onTap: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Page2(),
                      ),
                    );
                  },
                  child: Icon(Icons.arrow_left),
                ),
                ),
    ],
    ),
    ),
      ),
    );
  }
}
