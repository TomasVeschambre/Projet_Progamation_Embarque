import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'Page_Accueil.dart';
import 'Page 2.dart';
import 'url.dart';



class Academique extends StatefulWidget {

  @override
  _AcademiqueState createState() => _AcademiqueState();
}

class _AcademiqueState extends State<Academique> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
          backgroundColor: Colors.black,
        body: SafeArea(
        child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
        Expanded (
        child : GestureDetector(
        onTap: (){
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => Page_Accueil(),
        ),
      );
    },
    child : Container(
    margin: EdgeInsets.all(15.0),
    decoration: BoxDecoration(
    color: Colors.deepOrangeAccent,
    borderRadius: BorderRadius.circular(10.0)
    ),
    height : 200.0,
    width: 300.0,
    child : Row(
    children : [
    CircleAvatar(
    radius: 30.0,
    backgroundImage: AssetImage('images/zoro.jpeg'),
    ),
    Text('Tomas VESCHAMBRE')
    ],
    ),
    ),
    ),
    ),
          Expanded (
            child : Container(
              child: Center(
                child: Text(
                  "Formation Académique",
                  style : TextStyle(
                    fontSize: 25.0,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child : GestureDetector(
              onTap: () {
              },
            child : Container(
              margin: EdgeInsets.all(15.0),
              padding: EdgeInsets.all(20.0),
              decoration: BoxDecoration(
                  color: Colors.deepOrangeAccent,
                  borderRadius: BorderRadius.circular(10.0)
              ),
              height : 150.0,
              width: 300.0,
                  child : Center(
                  child : Text(
                    'BAC STI2D',
                    style: TextStyle(
                      fontSize:20.0,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
              ),
            ),
            ),
            ),
          Expanded(
            child : Container(
              margin: EdgeInsets.all(15.0),
              padding: EdgeInsets.all(15.0),
              decoration: BoxDecoration(
                  color: Colors.deepOrangeAccent,
                  borderRadius: BorderRadius.circular(10.0)
              ),
              height : 150.0,
              width: 300.0,
                  child: Center(
                  child : Text(
                    'CPGE TSI',
                    style: TextStyle(
                      fontSize:20.0,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  ),
          ),
          ),
          Expanded(
            child : Container(
              margin: EdgeInsets.all(15.0),
              padding: EdgeInsets.all(15.0),
              decoration: BoxDecoration(
                  color: Colors.deepOrangeAccent,
                  borderRadius: BorderRadius.circular(10.0)
              ),
              height : 150.0,
              width: 300.0,
                  child: Center(
                  child: Text(
                    'EPISEN ITS',
                    style: TextStyle(
                      fontSize:20.0,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  ),
              ),
            ),
          FloatingActionButton(
            child : GestureDetector(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Page2(),
                  ),
                );
              },
              child: Icon(Icons.arrow_left),
            ),
          ),
      ],
    ),
    ),
    ),
    );
  }
}
