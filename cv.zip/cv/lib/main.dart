import 'package:flutter/material.dart';
import 'Page_Accueil.dart';

void main() {
  runApp(CV());
}

class CV extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData.dark().copyWith(
      primaryColor: Colors.black,
      scaffoldBackgroundColor: Colors.black,
        ),
      home : Page_Accueil()
    );
  }
}


