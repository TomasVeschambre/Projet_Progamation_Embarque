import 'package:flutter/material.dart';
import 'Page 2.dart';
import 'Page_Accueil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class Autres extends StatefulWidget {
  @override
  _State createState() => _State();
}

class _State extends State<Autres> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded (
                child : GestureDetector(
                  onTap: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Page_Accueil(),
                      ),
                    );
                  },
                  child : Container(
                    margin: EdgeInsets.all(15.0),
                    decoration: BoxDecoration(
                        color: Colors.deepOrangeAccent,
                        borderRadius: BorderRadius.circular(10.0)
                    ),
                    height : 200.0,
                    width: 300.0,
                    child : Row(
                      children : [
                        CircleAvatar(
                          radius: 30.0,
                          backgroundImage: AssetImage('images/zoro.jpeg'),
                        ),
                        Text('Tomas VESCHAMBRE')
                      ],
                    ),
                  ),
                ),
              ),
              Expanded (
                child : Container(
                  child: Center(
                    child: Text(
                      "Hobbies",
                      style : TextStyle(
                        fontSize: 40.0,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child : Container(
                  margin: EdgeInsets.all(15.0),
                  padding: EdgeInsets.all(20.0),
                  decoration: BoxDecoration(
                      color: Colors.deepOrangeAccent,
                      borderRadius: BorderRadius.circular(10.0)
                  ),
                  height : 150.0,
                  width: 300.0,
                  child : ListTile(
                      leading : Icon(
                        FontAwesomeIcons.dumbbell,
                        size: 15.0,
                        color: Colors.white,
                      ),
                     title : Text(
                        'Sport',
                        style: TextStyle(
                          fontSize:20.0,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                  ),
                ),
              ),
              Expanded(
                child : Container(
                  margin: EdgeInsets.all(15.0),
                  padding: EdgeInsets.all(15.0),
                  decoration: BoxDecoration(
                      color: Colors.deepOrangeAccent,
                      borderRadius: BorderRadius.circular(10.0)
                  ),
                  height : 150.0,
                  width: 300.0,
                  child : ListTile(
                      leading : Icon(
                        FontAwesomeIcons.book,
                        size: 20.0,
                        color: Colors.white,
                      ),
                     title : Text(
                        'Manga',
                        style: TextStyle(
                          fontSize:20.0,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                  ),
                ),
              ),
              Expanded(
                child : Container(
                  margin: EdgeInsets.all(15.0),
                  padding: EdgeInsets.all(15.0),
                  decoration: BoxDecoration(
                      color: Colors.deepOrangeAccent,
                      borderRadius: BorderRadius.circular(10.0)
                  ),
                  height : 150.0,
                  width: 300.0,
                  child : ListTile(
                     leading : Icon(
                        FontAwesomeIcons.playstation,
                        size: 20.0,
                        color: Colors.white,
                      ),
                      title : Text(
                        'Jeux Vidéo',
                        style: TextStyle(
                          fontSize:20.0,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                  ),
                ),
              ),
              FloatingActionButton(
                child : GestureDetector(
                  onTap: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Page2(),
                      ),
                    );
                  },
                  child: Icon(Icons.arrow_left),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
