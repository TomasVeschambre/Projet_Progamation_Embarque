package com.tomasveschambre.cv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
